module.exports = require('koa-json-error');
