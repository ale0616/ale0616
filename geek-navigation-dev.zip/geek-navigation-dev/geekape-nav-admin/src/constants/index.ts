export const PERSISTENCE_TYPE = 'session';
export const TOKEN = 'token';
export const CURRENT_USER = 'currentUser';
